package com.ademclient;

import com.ademclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class AdemClient implements ClientModInitializer {
    public static final String NAME = "AdemClient";
    public static ModuleManager moduleManager;

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        moduleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            moduleManager.onTick(client);
        });

        System.out.println("[AdemClient] Loaded — " + moduleManager.getModules().size() + " modules active.");
    }
}
