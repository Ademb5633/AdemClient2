package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerAbilities;
import org.lwjgl.glfw.GLFW;

public class Flight extends Module {

    public Flight() {
        super("Flight", GLFW.GLFW_KEY_F);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        PlayerAbilities ab = client.player.getAbilities();
        ab.allowFlying = true;
        ab.flying = true;
        ab.setFlySpeed(0.05f);
        client.player.sendAbilitiesUpdate();
    }

    @Override
    public void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        if (!client.player.isCreative() && !client.player.isSpectator()) {
            PlayerAbilities ab = client.player.getAbilities();
            ab.allowFlying = false;
            ab.flying = false;
            client.player.sendAbilitiesUpdate();
        }
    }
}
