package com.ademclient.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

public class RenderUtil {

    public static void drawOutlinedBox(MatrixStack matrices, Box box,
                                       float r, float g, float b, float a) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        MinecraftClient mc = MinecraftClient.getInstance();
        VertexConsumerProvider.Immediate immediate =
            mc.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer vc = immediate.getBuffer(RenderLayer.getLines());

        line(vc, matrix, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(vc, matrix, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(vc, matrix, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(vc, matrix, x1,y1,z2, x1,y1,z1, r,g,b,a);

        line(vc, matrix, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(vc, matrix, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(vc, matrix, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(vc, matrix, x1,y2,z2, x1,y2,z1, r,g,b,a);

        line(vc, matrix, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(vc, matrix, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(vc, matrix, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(vc, matrix, x1,y1,z2, x1,y2,z2, r,g,b,a);

        immediate.draw(RenderLayer.getLines());
    }

    private static void line(VertexConsumer vc, Matrix4f m,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a) {
        float nx = x2-x1, ny = y2-y1, nz = z2-z1;
        float len = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (len == 0) return;
        nx/=len; ny/=len; nz/=len;
        vc.vertex(m, x1,y1,z1).color(r,g,b,a).normal(nx,ny,nz).next();
        vc.vertex(m, x2,y2,z2).color(r,g,b,a).normal(nx,ny,nz).next();
    }
}
