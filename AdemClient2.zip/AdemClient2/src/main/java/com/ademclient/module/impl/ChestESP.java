package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public class ChestESP extends Module {
    public static ChestESP INSTANCE;

    public ChestESP() {
        super("ChestESP", GLFW.GLFW_KEY_C);
        INSTANCE = this;
    }

    public void renderChests(MinecraftClient client, MatrixStack matrices, Camera camera) {
        if (!isEnabled() || client.world == null) return;

        double cx = camera.getPos().x;
        double cy = camera.getPos().y;
        double cz = camera.getPos().z;

        for (BlockEntity be : client.world.blockEntities) {
            if (!(be instanceof ChestBlockEntity)
                && !(be instanceof TrappedChestBlockEntity)
                && !(be instanceof BarrelBlockEntity)
                && !(be instanceof ShulkerBoxBlockEntity)) continue;

            BlockPos pos = be.getPos();
            matrices.push();
            matrices.translate(pos.getX() - cx, pos.getY() - cy, pos.getZ() - cz);
            RenderUtil.drawOutlinedBox(matrices, new Box(0,0,0,1,1,1), 1f, 0.75f, 0f, 1f);
            matrices.pop();
        }
    }
}
